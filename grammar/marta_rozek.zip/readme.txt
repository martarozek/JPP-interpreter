Marta Rożek
360953

The language is a subset of haskell (with semicolons). I expect it’s worth between 16 and 20 points. Apart from the standard requirements for 16 points the solution can interpret pattern-matching on lists with multiple layers.

Features:
 - two types: Int, Bool,
 - arithmetic, relational operators,
 - declarative if,
 - functions with multiple parameters, 
 - recursion,
 - anonymous functions, partial application and higher-order functions,
 - lists:
   * pattern-matching (to an arbitrary depth): x:xs, [x,y],
   * constructors: x:xs, [x,y].
